<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Purchase | FuelTracker</title>
    <link rel="icon" type="image/jpeg" href="{{ asset('images/fueltracker-logo.jpeg') }}">
    <link rel="shortcut icon" type="image/jpeg" href="{{ asset('images/fueltracker-logo.jpeg') }}">
    <style>
        :root {
            --bg: #f4f7fb;
            --panel: #ffffff;
            --ink: #172033;
            --muted: #657089;
            --line: #dce3ee;
            --primary: #0f766e;
            --primary-dark: #115e59;
            --danger: #b42318;
            --shadow: 0 16px 48px rgba(23, 32, 51, 0.10);
        }

        * {
            box-sizing: border-box;
        }

        [hidden] {
            display: none !important;
        }

        body {
            margin: 0;
            height: 100vh;
            min-height: 100vh;
            overflow-x: hidden;
            overflow-y: hidden;
            font-family: Arial, Helvetica, sans-serif;
            color: var(--ink);
            background: linear-gradient(135deg, #f8fbff 0%, var(--bg) 55%, #eef5f3 100%);
        }

        .site-header {
            position: sticky;
            top: 0;
            z-index: 20;
            width: 100%;
            background: linear-gradient(135deg, rgba(8, 47, 73, 0.98), rgba(15, 118, 110, 0.98));
            box-shadow: 0 10px 30px rgba(23, 32, 51, 0.12);
        }

        .site-header-inner {
            width: 100%;
            min-height: 64px;
            display: grid;
            grid-template-columns: minmax(220px, 1fr) auto minmax(220px, 1fr);
            align-items: center;
            gap: 18px;
            padding: 0 12px;
        }

        .site-logo {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #ffffff;
            font-size: 21px;
            font-weight: 700;
            text-decoration: none;
        }

        .site-logo-icon {
            display: grid;
            width: 38px;
            height: 38px;
            place-items: center;
            border-radius: 999px;
            background: #ffffff;
            overflow: hidden;
            padding: 2px;
        }

        .app-logo-image {
            display: block;
            width: 100%;
            height: 100%;
            border-radius: inherit;
            object-fit: cover;
        }

        .header-title {
            justify-self: center;
            color: #ffffff;
            font-size: 20px;
            font-weight: 700;
            white-space: nowrap;
        }

        .header-actions {
            display: flex;
            align-items: center;
            justify-self: end;
            gap: 10px;
        }

        .back-link,
        .logout-btn {
            min-height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0 14px;
            border: 1px solid rgba(255, 255, 255, 0.24);
            border-radius: 8px;
            color: #ffffff;
            background: rgba(255, 255, 255, 0.12);
            cursor: pointer;
            font: inherit;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
        }

        .purchase-workspace.app-shell-with-sidebar {
            width: calc(100vw - 24px);
            height: calc(100vh - 88px);
            min-height: 0;
            grid-template-columns: 300px minmax(0, 1fr);
            margin: 12px;
            border-radius: 12px;
            overflow: hidden;
        }

        .purchase-workspace.app-shell-with-sidebar.menu-collapsed {
            grid-template-columns: 64px minmax(0, 1fr);
        }

        .purchase-page {
            width: 100%;
            min-width: 0;
            height: 100%;
            min-height: 0;
            display: flex;
            flex-direction: column;
            margin: 0;
            padding: 14px;
            overflow: hidden;
        }

        .page-title,
        .panel {
            border: 1px solid rgba(220, 227, 238, 0.86);
            border-radius: 12px;
            background: var(--panel);
            box-shadow: var(--shadow);
        }

        .page-title {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 12px;
            padding: 18px;
        }

        .eyebrow {
            margin: 0 0 5px;
            color: var(--primary);
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
        }

        h1,
        h2 {
            margin: 0;
        }

        h1 {
            font-size: 30px;
            line-height: 1.2;
        }

        .panel {
            overflow: hidden;
        }

        .record-count {
            flex: 0 0 auto;
            padding: 6px 10px;
            border-radius: 999px;
            color: var(--primary-dark);
            background: rgba(15, 118, 110, 0.09);
            font-size: 11px;
            font-weight: 700;
        }

        .content-grid {
            display: grid;
            grid-template-rows: minmax(250px, 1fr) auto auto;
            gap: 12px;
            flex: 1 1 auto;
            min-height: 0;
            overflow: hidden;
            padding-right: 4px;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) color-mix(in srgb, var(--primary) 12%, var(--line));
        }

        .content-grid::-webkit-scrollbar,
        .purchase-form::-webkit-scrollbar,
        .table-wrap::-webkit-scrollbar,
        .theme-dropdown-menu::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        .content-grid::-webkit-scrollbar-track,
        .purchase-form::-webkit-scrollbar-track,
        .table-wrap::-webkit-scrollbar-track,
        .theme-dropdown-menu::-webkit-scrollbar-track {
            border-radius: 999px;
            background: color-mix(in srgb, var(--primary) 12%, var(--line));
        }

        .content-grid::-webkit-scrollbar-thumb,
        .purchase-form::-webkit-scrollbar-thumb,
        .table-wrap::-webkit-scrollbar-thumb,
        .theme-dropdown-menu::-webkit-scrollbar-thumb {
            border: 2px solid color-mix(in srgb, var(--primary) 12%, var(--line));
            border-radius: 999px;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary) 62%, var(--primary-shine));
        }

        .content-grid::-webkit-scrollbar-thumb:hover,
        .purchase-form::-webkit-scrollbar-thumb:hover,
        .table-wrap::-webkit-scrollbar-thumb:hover,
        .theme-dropdown-menu::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        }

        .form-panel {
            position: relative;
            z-index: 10;
            display: flex;
            max-height: none;
            min-height: 0;
            flex-direction: column;
        }

        .form-panel.has-open-dropdown {
            z-index: 200;
        }

        .list-panel {
            position: relative;
            z-index: 1;
            display: flex;
            min-height: 0;
            flex-direction: column;
            overflow: hidden;
        }

        .panel-head,
        .table-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 13px 14px;
            border-bottom: 1px solid var(--line);
            background: #fbfcfe;
        }

        .panel-head h2,
        .toolbar-title {
            color: var(--ink);
            font-size: 18px;
            font-weight: 800;
            line-height: 1.25;
        }

        .toolbar-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
            flex: 1 1 auto;
            min-width: 0;
            flex-wrap: nowrap;
        }

        .toolbar-total {
            flex: 0 0 auto;
            color: var(--primary-dark);
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }

        .list-search {
            width: min(260px, 28vw);
            flex: 0 1 260px;
            min-height: 34px;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #ffffff;
            color: var(--ink);
            font-size: 12px;
            font-weight: 700;
        }

        .export-actions {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            flex: 0 0 auto;
        }

        .export-btn {
            min-height: 34px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0 14px;
            border: 1px solid transparent;
            border-radius: 8px;
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .export-btn:hover,
        .export-btn:focus {
            outline: none;
        }

        .purchase-form {
            display: grid;
            flex: 1 1 auto;
            gap: 12px;
            min-height: 0;
            padding: 12px 14px 14px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) color-mix(in srgb, var(--primary) 12%, var(--line));
        }

        .purchase-summary-grid {
            display: grid;
            grid-template-columns: repeat(7, minmax(120px, 1fr));
            gap: 10px;
            margin: 12px 14px 14px;
            padding-top: 2px;
        }

        .summary-box {
            display: grid;
            gap: 5px;
            min-height: 74px;
            padding: 11px 12px;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fbfcfe;
            box-shadow: 0 8px 22px rgba(23, 32, 51, 0.06);
        }

        .summary-label {
            color: var(--muted);
            font-size: 11px;
            font-weight: 800;
            line-height: 1.25;
            text-transform: uppercase;
        }

        .summary-value {
            color: var(--ink);
            font-size: 17px;
            font-weight: 800;
            line-height: 1.2;
            overflow-wrap: anywhere;
        }

        .summary-box.total {
            border-color: rgba(15, 118, 110, 0.25);
            background: rgba(15, 118, 110, 0.08);
        }

        .summary-box.total .summary-value {
            color: var(--primary-dark);
        }

        .form-alert {
            margin: 14px 14px 0;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
        }

        .form-alert.success {
            color: #115e59;
            border: 1px solid rgba(15, 118, 110, 0.22);
            background: rgba(15, 118, 110, 0.08);
        }

        .form-alert.is-hiding {
            opacity: 0;
            transform: translateY(-6px);
            transition: opacity 180ms ease, transform 180ms ease;
        }

        .form-alert.error {
            color: #b42318;
            border: 1px solid rgba(180, 35, 24, 0.16);
            background: #fff1f0;
        }

        .form-alert ul {
            margin: 6px 0 0;
            padding-left: 18px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(150px, 1fr));
            gap: 12px;
            align-items: end;
        }

        .field {
            position: relative;
            display: grid;
            gap: 5px;
        }

        .field.wide {
            grid-column: span 2;
        }

        label {
            color: var(--muted);
            font-size: 11px;
            font-weight: 700;
        }

        .char-limit {
            position: absolute;
            right: 0;
            bottom: -14px;
            color: var(--muted);
            font-size: 11px;
            font-weight: 700;
            text-align: right;
        }

        input,
        select,
        textarea {
            width: 100%;
            min-height: 34px;
            border: 1px solid var(--line);
            border-radius: 8px;
            color: var(--ink);
            background: #ffffff;
            font: inherit;
            font-size: 13px;
            outline: none;
            padding: 0 10px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(15, 118, 110, 0.12);
        }

        input:disabled {
            color: var(--muted);
            background: #f1f4f8;
            cursor: not-allowed;
        }

        textarea {
            min-height: 64px;
            resize: vertical;
        }

        .theme-dropdown {
            position: relative;
            height: 34px;
            min-height: 0;
            display: block;
        }

        .theme-dropdown.is-open {
            z-index: 120;
        }

        .theme-dropdown-value {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        .theme-dropdown-button {
            width: 100%;
            height: 100%;
            min-height: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 0 10px;
            border: 1px solid var(--line);
            border-radius: 8px;
            color: var(--ink);
            background: #ffffff;
            cursor: pointer;
            font: inherit;
            font-size: 13px;
            outline: none;
            text-align: left;
        }

        .theme-dropdown-button:hover,
        .theme-dropdown-button:focus {
            border-color: rgba(15, 118, 110, 0.52);
            background: rgba(15, 118, 110, 0.07);
            box-shadow: 0 0 0 4px rgba(15, 118, 110, 0.13);
        }

        .theme-dropdown-text {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .theme-dropdown-arrow {
            width: 9px;
            height: 9px;
            flex: 0 0 auto;
            border-right: 2px solid currentColor;
            border-bottom: 2px solid currentColor;
            transform: translateY(-2px) rotate(45deg);
        }

        .theme-dropdown-menu {
            position: absolute;
            top: calc(100% + 6px);
            right: 0;
            left: 0;
            z-index: 40;
            display: none;
            max-height: 210px;
            overflow-y: auto;
            margin: 0;
            padding: 4px;
            border: 1px solid color-mix(in srgb, var(--primary) 22%, var(--line));
            border-radius: 12px;
            background: #ffffff;
            box-shadow: 0 14px 32px rgba(23, 32, 51, 0.16);
            list-style: none;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) color-mix(in srgb, var(--primary) 12%, var(--line));
        }

        .theme-dropdown.is-open .theme-dropdown-menu {
            display: block;
        }

        .theme-dropdown-search-wrap {
            position: sticky;
            top: -4px;
            z-index: 1;
            padding: 4px 4px 6px;
            background: #ffffff;
        }

        .theme-dropdown-search {
            width: 100%;
            min-height: 34px;
            padding: 0 10px;
            border: 1px solid var(--line);
            border-radius: 9px;
            color: var(--ink);
            background: #fbfcfe;
            font: inherit;
            font-size: 13px;
            outline: none;
        }

        .theme-dropdown-search:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--primary) 18%, transparent);
        }

        .theme-dropdown-option {
            width: 100%;
            min-height: 36px;
            padding: 0 10px;
            border: 0;
            border-radius: 9px;
            color: var(--ink);
            background: transparent;
            cursor: pointer;
            font: inherit;
            font-size: 13px;
            text-align: left;
        }

        .theme-dropdown-option:hover,
        .theme-dropdown-option:focus,
        .theme-dropdown-option.is-selected {
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            outline: none;
        }

        .theme-dropdown-option:disabled {
            color: var(--muted);
            background: transparent;
            cursor: default;
        }

        .theme-dropdown-empty {
            display: none;
            min-height: 32px;
            padding: 8px 10px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 700;
        }

        .theme-dropdown-empty.is-visible {
            display: block;
        }

        .table-wrap {
            max-height: 178px;
            overflow: auto;
            background: #ffffff;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) color-mix(in srgb, var(--primary) 12%, var(--line));
        }

        .pending-list-panel .table-wrap {
            max-height: 148px;
        }

        .batch-save-btn:disabled {
            opacity: 0.55;
            cursor: not-allowed;
        }

        table {
            width: 100%;
            min-width: 1220px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--line);
            font-size: 13px;
            text-align: left;
            vertical-align: middle;
            white-space: nowrap;
        }

        th {
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            font-weight: 800;
        }

        tbody tr:hover {
            background: color-mix(in srgb, var(--primary) 8%, #ffffff);
        }

        td {
            background: #ffffff;
        }

        .items-table input,
        .items-table select {
            min-height: 34px;
            border: 0;
            border-radius: 0;
            background: transparent;
            font-size: 13px;
            box-shadow: none;
        }

        .items-table input:focus,
        .items-table select:focus {
            box-shadow: inset 0 0 0 2px rgba(15, 118, 110, 0.20);
        }

        .number-input,
        .number-cell {
            text-align: right;
        }

        .form-actions {
            grid-column: 1 / -1;
            position: sticky;
            bottom: -14px;
            z-index: 30;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin: 0 -14px -14px;
            padding: 10px 14px;
            border-top: 1px solid var(--line);
            background:
                linear-gradient(135deg, color-mix(in srgb, var(--primary) 7%, #ffffff), rgba(255, 255, 255, 0.98)),
                #ffffff;
            box-shadow: 0 -10px 24px rgba(23, 32, 51, 0.08);
        }

        .secondary-actions,
        .primary-actions,
        .row-actions {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn,
        .update-btn,
        .delete-btn,
        .modal-no-btn,
        .modal-yes-btn {
            min-height: 34px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0 14px;
            border-radius: 8px;
            cursor: pointer;
            font: inherit;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
        }

        .save-btn {
            border: 1px solid transparent;
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        }

        .clear-btn {
            border: 1px solid var(--line);
            color: var(--muted);
            background: #ffffff;
        }

        .sample-btn {
            border: 1px solid color-mix(in srgb, var(--primary) 34%, var(--line));
            color: var(--primary-dark);
            background: color-mix(in srgb, var(--primary) 10%, #ffffff);
        }

        .cancel-edit-btn,
        .modal-no-btn {
            border: 1px solid var(--line);
            color: var(--muted);
            background: #ffffff;
        }

        .update-btn {
            min-height: 30px;
            padding: 0 12px;
            border: 1px solid rgba(15, 118, 110, 0.24);
            color: var(--primary-dark);
            background: rgba(15, 118, 110, 0.08);
        }

        .delete-btn,
        .modal-yes-btn {
            min-height: 30px;
            padding: 0 12px;
            border: 1px solid rgba(180, 35, 24, 0.16);
            color: var(--danger);
            background: #fff1f0;
        }

        .update-btn:hover {
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        }

        .delete-btn:hover,
        .modal-yes-btn {
            color: #ffffff;
            background: var(--danger);
        }

        .clear-btn:hover {
            color: var(--primary-dark);
            border-color: rgba(15, 118, 110, 0.36);
        }

        .sample-btn:hover {
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        }

        .empty-state {
            padding: 34px 16px;
            color: var(--muted);
            font-size: 14px;
            font-weight: 700;
            text-align: center;
        }

        .delete-modal {
            position: fixed;
            inset: 0;
            z-index: 80;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 18px;
            background: rgba(15, 23, 42, 0.45);
        }

        .delete-modal.is-open {
            display: flex;
        }

        .density-alert-modal {
            z-index: 120;
            background: rgba(15, 23, 42, 0.36);
        }

        .delete-dialog {
            width: min(420px, 100%);
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 12px;
            background: #ffffff;
            box-shadow: 0 24px 60px rgba(15, 23, 42, 0.24);
        }

        .delete-dialog-title {
            margin: 0 0 8px;
            font-size: 18px;
        }

        .density-alert-title {
            color: var(--danger);
        }

        .delete-dialog-body {
            margin: 0 0 16px;
            color: var(--muted);
            font-size: 13px;
            font-weight: 700;
        }

        .delete-dialog-actions {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
        }

        .density-alert-ok {
            min-width: 82px;
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            border-color: transparent;
        }

        .sample-preview-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 8px;
            margin-bottom: 16px;
        }

        .sample-preview-item {
            display: grid;
            gap: 3px;
            padding: 8px 10px;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fbfcfe;
        }

        .sample-preview-item span {
            color: var(--muted);
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
        }

        .sample-preview-item strong {
            color: var(--ink);
            font-size: 13px;
            overflow-wrap: anywhere;
        }

        .sample-modal {
            position: fixed;
            inset: 0;
            z-index: 90;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(15, 23, 42, 0.45);
        }

        .sample-modal.is-open {
            display: flex;
        }

        .sample-window {
            width: min(1180px, 100%);
            max-height: calc(100vh - 40px);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            border: 1px solid color-mix(in srgb, var(--primary) 36%, var(--line));
            border-radius: 12px;
            background: #f8fbff;
            box-shadow: 0 28px 80px rgba(15, 23, 42, 0.28);
        }

        .sample-window-head {
            min-height: 46px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 0 14px 0 18px;
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        }

        .sample-window-title {
            font-size: 18px;
            font-weight: 800;
        }

        .sample-close-btn {
            width: 34px;
            height: 34px;
            border: 1px solid rgba(255, 255, 255, 0.22);
            border-radius: 8px;
            color: #ffffff;
            background: rgba(255, 255, 255, 0.12);
            cursor: pointer;
            font-size: 20px;
            font-weight: 800;
            line-height: 1;
        }

        .sample-form {
            display: grid;
            grid-template-columns: 390px minmax(0, 1fr);
            gap: 18px;
            padding: 18px;
            overflow: auto;
        }

        .sample-details,
        .sample-product-card {
            border: 1px solid var(--line);
            border-radius: 10px;
            background: #ffffff;
            box-shadow: 0 10px 28px rgba(23, 32, 51, 0.08);
        }

        .sample-details {
            display: grid;
            gap: 12px;
            align-content: start;
            padding: 16px;
        }

        .sample-field {
            display: grid;
            grid-template-columns: 140px minmax(0, 1fr);
            align-items: center;
            gap: 12px;
        }

        .sample-field label,
        .sample-line label {
            color: var(--ink);
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
        }

        .sample-field input,
        .sample-line input {
            min-height: 34px;
            border-radius: 6px;
            background: #ffffff;
        }

        .sample-products {
            display: grid;
            grid-template-columns: repeat(3, minmax(190px, 1fr));
            gap: 14px;
        }

        .sample-product-card {
            padding: 14px;
        }

        .sample-product-card.is-inactive {
            opacity: 0.46;
            background: #f4f7fb;
        }

        .sample-product-card.is-inactive input {
            cursor: not-allowed;
        }

        .sample-product-card h3 {
            margin: 0 0 14px;
            color: var(--ink);
            font-size: 20px;
            text-align: center;
        }

        .sample-line {
            display: grid;
            grid-template-columns: minmax(95px, 1fr) minmax(86px, 110px);
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }

        .sample-preview-btn {
            width: 100%;
            min-height: 34px;
            margin-top: 8px;
            border: 1px solid rgba(15, 118, 110, 0.24);
            border-radius: 8px;
            color: var(--primary-dark);
            background: rgba(15, 118, 110, 0.08);
            cursor: pointer;
            font: inherit;
            font-size: 12px;
            font-weight: 800;
        }

        .sample-preview-btn:hover,
        .sample-preview-btn:focus {
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            outline: none;
        }

        .sample-preview-btn:disabled {
            color: var(--muted);
            background: #eef2f7;
            cursor: not-allowed;
        }

        .sample-window-actions {
            display: flex;
            justify-content: center;
            padding: 14px 18px 18px;
            border-top: 1px solid var(--line);
            background: #ffffff;
        }

        .sample-save-btn {
            min-width: 150px;
            min-height: 40px;
            border: 1px solid transparent;
            border-radius: 8px;
            color: #ffffff;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            cursor: pointer;
            font: inherit;
            font-size: 15px;
            font-weight: 800;
        }

        .add-item-field {
            align-self: end;
        }

        @media (max-width: 980px) {
            .site-header-inner {
                grid-template-columns: 1fr;
                gap: 8px;
                padding: 10px;
            }

            .header-title,
            .header-actions {
                justify-self: center;
            }

            .form-grid {
                grid-template-columns: 1fr 1fr;
            }

            .field.wide {
                grid-column: span 2;
            }

            .purchase-summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .sample-form {
                grid-template-columns: 1fr;
            }

            .sample-products {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .purchase-workspace.app-shell-with-sidebar {
                width: auto;
                margin: 10px;
            }

            .purchase-page {
                padding: 10px;
            }

            .page-title,
            .panel-head,
            .form-actions {
                align-items: flex-start;
                flex-direction: column;
            }

            .table-toolbar,
            .toolbar-actions {
                align-items: flex-start;
                flex-direction: column;
            }

            .list-search {
                width: 100%;
                flex-basis: auto;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .purchase-summary-grid {
                grid-template-columns: 1fr;
            }

            .field.wide {
                grid-column: auto;
            }

            .sample-field {
                grid-template-columns: 1fr;
            }
        }
    </style>
    @include('partials.theme')
</head>
<body>
    @php
        $purchases = collect($purchases ?? []);
        $totalTaxableAmount = $purchases->sum(fn ($purchase) => (float) ($purchase->taxable_amount ?? 0));
        $totalCgstAmount = $purchases->sum(fn ($purchase) => ((float) ($purchase->taxable_amount ?? 0) * (float) ($purchase->cgst ?? 0)) / 100);
        $totalSgstAmount = $purchases->sum(fn ($purchase) => ((float) ($purchase->taxable_amount ?? 0) * (float) ($purchase->sgst ?? 0)) / 100);
        $totalIgstAmount = $purchases->sum(fn ($purchase) => ((float) ($purchase->taxable_amount ?? 0) * (float) ($purchase->igst ?? 0)) / 100);
        $totalDiscountAmount = $purchases->sum(fn ($purchase) => (float) ($purchase->discountinrs ?? 0));
        $totalPurchaseAmount = $purchases->sum(fn ($purchase) => (float) ($purchase->total_amount ?? 0));
        $today = old('date', $selectedDate ?? now()->toDateString());
        $particularAccounts = collect($perticular ?? []);
        $accountDetailsByName = $particularAccounts->mapWithKeys(function ($party) {
            $partyName = is_object($party) ? ($party->account_perticular ?? '') : (string) $party;

            return [$partyName => [
                'address' => is_object($party) ? ($party->address ?? '') : '',
                'location' => is_object($party) ? ($party->city ?? '') : '',
            ]];
        });
        $items = collect($item ?? []);
        $selectedParticular = old('perticulars', '');
        $selectedItem = old('item_name', '');
        $selectedInterstate = old('interstate', 'No');
        $storeUrl = \Illuminate\Support\Facades\Route::has('purchase.store') ? route('purchase.store') : route('purchase');
        $listUrl = \Illuminate\Support\Facades\Route::has('purchase') ? route('purchase') : url('/purchase');
        $hasUpdateRoute = \Illuminate\Support\Facades\Route::has('purchase.update');
        $hasDestroyRoute = \Illuminate\Support\Facades\Route::has('purchase.destroy');
        $hasPdfRoute = \Illuminate\Support\Facades\Route::has('purchase.pdf');
        $hasExcelRoute = \Illuminate\Support\Facades\Route::has('purchase.excel');
        $hasSampleStoreRoute = \Illuminate\Support\Facades\Route::has('purchase.sample.store');
        $samplePreviewUrl = \Illuminate\Support\Facades\Route::has('purchase.sample.preview') ? route('purchase.sample.preview') : url('/purchase/sample/preview');
        $hasSamplePdfRoute = \Illuminate\Support\Facades\Route::has('purchase.sample.pdf');
        $hasSampleExcelRoute = \Illuminate\Support\Facades\Route::has('purchase.sample.excel');
        $purchaseSamples = collect($purchaseSamples ?? []);
        $latestPurchaseForSample = $purchases->sortByDesc(fn ($purchase) => (int) ($purchase->id ?? 0))->first();
        $sampleProductKey = function ($productName) {
            $name = strtolower(trim((string) $productName));

            if ($name === '') {
                return null;
            }

            if (str_contains($name, 'power') || str_contains($name, 'po-ms') || str_contains($name, 'po ms')) {
                return 'power-ms';
            }

            if (str_contains($name, 'diesel') || str_contains($name, 'deisel') || str_contains($name, 'deisle') || str_contains($name, 'diesal') || str_contains($name, 'desal') || str_contains($name, 'hsd')) {
                return 'hsd';
            }

            if (str_contains($name, 'petrol') || preg_match('/\bms\b/', $name)) {
                return 'ms';
            }

            return null;
        };
        $sampleActiveProducts = $purchases
            ->map(fn ($purchase) => $sampleProductKey($purchase->item_name ?? ''))
            ->filter()
            ->unique()
            ->values()
            ->all();
        $samplePrefillPurchase = $latestPurchaseForSample ? [
            'date' => substr((string) $latestPurchaseForSample->date, 0, 10),
            'tanker' => $latestPurchaseForSample->vehicle_no ?? '',
            'transport' => $latestPurchaseForSample->transporter ?? '',
            'oil_company' => $latestPurchaseForSample->perticulars ?? '',
            'invoice_no' => $latestPurchaseForSample->invoice_no ?? '',
        ] : [
            'date' => $today,
            'tanker' => '',
            'transport' => '',
            'oil_company' => '',
            'invoice_no' => '',
        ];
    @endphp

    <header class="site-header">
        <div class="site-header-inner">
            <a href="{{ url('/dashboard') }}" class="site-logo" aria-label="FuelTracker dashboard">
                <span class="site-logo-icon" aria-hidden="true">
                    <img src="{{ asset('images/fueltracker-logo.jpeg') }}" alt="" class="app-logo-image">
                </span>
                <span>FuelTracker</span>
            </a>
            <div class="header-title">Purchase Entry</div>
            <div class="header-actions">
                <a href="{{ url('/dashboard') }}" class="back-link">Dashboard</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
        </div>
    </header>

    <div class="app-shell-with-sidebar purchase-workspace" id="dashboardPage">
        @include('partials.fueltracker-menu')

        <main class="purchase-page">
            <section class="page-title" aria-labelledby="purchaseTitle">
                <div>
                    <p class="eyebrow">Transactions</p>
                    <h1 id="purchaseTitle">Purchase</h1>
                </div>
                <span class="record-count">{{ $purchases->count() }} {{ $purchases->count() === 1 ? 'entry' : 'entries' }}</span>
            </section>

            <div class="content-grid">
            <section class="panel form-panel" aria-labelledby="purchaseEntryTitle">
                <div class="panel-head">
                    <h2 id="purchaseEntryTitle">Purchase Entry</h2>
                </div>

                @if (session('success'))
                    <div class="form-alert success" id="success-message">{{ session('success') }}</div>
                @endif

                @if (session('error'))
                    <div class="form-alert error">{{ session('error') }}</div>
                @endif

                @if ($errors->any())
                    <div class="form-alert error">
                        Please fix the highlighted details.
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form class="purchase-form" id="purchaseForm" method="POST" action="{{ $storeUrl }}" data-store-url="{{ $storeUrl }}" autocomplete="off">
                    @csrf
                    <input type="hidden" name="_method" id="purchaseFormMethod" value="PUT" disabled>

                    <div class="form-grid">
                        <div class="field">
                            <label for="purchaseDate">Date</label>
                            <input id="purchaseDate" type="date" name="date" value="{{ $today }}">
                        </div>

                        <div class="field">
                            <label for="refNo">Ref. No.</label>
                            <input id="refNo" type="text" name="Ref_no" value="{{ old('Ref_no', $nextRefNo ?? 1) }}" readonly>
                        </div>

                        <div class="field">
                            <label for="invoiceNo">Invoice No.</label>
                            <input id="invoiceNo" type="text" name="invoice_no" value="{{ old('invoice_no') }}">
                        </div>

                        <div class="field wide">
                            <label for="perticulars">Perticulars</label>
                            <div class="theme-dropdown" data-theme-dropdown>
                                <input type="text" class="theme-dropdown-value" id="perticulars" name="perticulars" value="{{ $selectedParticular }}">
                                <button type="button" class="theme-dropdown-button" aria-haspopup="listbox" aria-expanded="false">
                                    <span class="theme-dropdown-text">{{ $selectedParticular ?: 'Select Particulars' }}</span>
                                    <span class="theme-dropdown-arrow" aria-hidden="true"></span>
                                </button>
                                <ul class="theme-dropdown-menu" role="listbox" aria-label="Particulars list">
                                    <li class="theme-dropdown-search-wrap">
                                        <input type="search" class="theme-dropdown-search" placeholder="Search particulars" autocomplete="off">
                                    </li>
                                    @forelse ($particularAccounts as $party)
                                        @php $partyName = is_object($party) ? ($party->account_perticular ?? '') : $party; @endphp
                                        <li>
                                            <button
                                                type="button"
                                                class="theme-dropdown-option {{ $selectedParticular === $partyName ? 'is-selected' : '' }}"
                                                data-value="{{ $partyName }}"
                                                data-address="{{ is_object($party) ? ($party->address ?? '') : '' }}"
                                                data-location="{{ is_object($party) ? ($party->city ?? '') : '' }}"
                                                role="option"
                                                aria-selected="{{ $selectedParticular === $partyName ? 'true' : 'false' }}"
                                            >
                                                {{ $partyName }}
                                            </button>
                                        </li>
                                    @empty
                                        <li><button type="button" class="theme-dropdown-option" disabled>No particulars found</button></li>
                                    @endforelse
                                    @if ($selectedParticular && !$particularAccounts->contains(fn ($party) => (is_object($party) ? ($party->account_perticular ?? '') : $party) === $selectedParticular))
                                        <li><button type="button" class="theme-dropdown-option is-selected" data-value="{{ $selectedParticular }}" role="option" aria-selected="true">{{ $selectedParticular }}</button></li>
                                    @endif
                                    <li class="theme-dropdown-empty">No matching particulars</li>
                                </ul>
                            </div>
                        </div>

                        <div class="field wide">
                            <label for="postalAddress">Postal Address</label>
                            <input id="postalAddress" type="text" name="postal address" maxlength="255" value="{{ old('postal address') }}" readonly>
                            <span class="char-limit" data-char-limit-for="postalAddress">0/255</span>
                        </div>

                        <div class="field">
                            <label for="location">Location</label>
                            <input id="location" type="text" name="location" maxlength="255" value="{{ old('location') }}" readonly>
                            <span class="char-limit" data-char-limit-for="location">0/255</span>
                        </div>

                        <div class="field">
                            <label for="interstate">Interstate</label>
                            <div class="theme-dropdown" data-theme-dropdown>
                                <input type="text" class="theme-dropdown-value" id="interstate" name="interstate" value="{{ $selectedInterstate }}">
                                <button type="button" class="theme-dropdown-button" aria-haspopup="listbox" aria-expanded="false">
                                    <span class="theme-dropdown-text">{{ $selectedInterstate }}</span>
                                    <span class="theme-dropdown-arrow" aria-hidden="true"></span>
                                </button>
                                <ul class="theme-dropdown-menu" role="listbox" aria-label="Interstate options">
                                    <li><button type="button" class="theme-dropdown-option {{ $selectedInterstate === 'Yes' ? 'is-selected' : '' }}" data-value="Yes" role="option" aria-selected="{{ $selectedInterstate === 'Yes' ? 'true' : 'false' }}">Yes</button></li>
                                    <li><button type="button" class="theme-dropdown-option {{ $selectedInterstate === 'No' ? 'is-selected' : '' }}" data-value="No" role="option" aria-selected="{{ $selectedInterstate === 'No' ? 'true' : 'false' }}">No</button></li>
                                    <li class="theme-dropdown-empty">No matching options</li>
                                </ul>
                            </div>
                        </div>

                        <div class="field wide">
                            <label for="itemName">Item Name</label>
                            <div class="theme-dropdown" data-theme-dropdown>
                                <input type="text" class="theme-dropdown-value" id="itemName" name="item_name" value="{{ $selectedItem }}">
                                <button type="button" class="theme-dropdown-button" aria-haspopup="listbox" aria-expanded="false">
                                    <span class="theme-dropdown-text">{{ $selectedItem ?: 'Select Item' }}</span>
                                    <span class="theme-dropdown-arrow" aria-hidden="true"></span>
                                </button>
                                <ul class="theme-dropdown-menu" role="listbox" aria-label="Item list">
                                    <li class="theme-dropdown-search-wrap">
                                        <input type="search" class="theme-dropdown-search" placeholder="Search item" autocomplete="off">
                                    </li>
                                    @forelse ($items as $product)
                                        @php $productName = is_object($product) ? ($product->Product_Name ?? '') : $product; @endphp
                                        <li>
                                            <button type="button" class="theme-dropdown-option {{ $selectedItem === $productName ? 'is-selected' : '' }}" data-value="{{ $productName }}" role="option" aria-selected="{{ $selectedItem === $productName ? 'true' : 'false' }}">
                                                {{ $productName }}
                                            </button>
                                        </li>
                                    @empty
                                        <li><button type="button" class="theme-dropdown-option" disabled>No items found</button></li>
                                    @endforelse
                                    @if ($selectedItem && !$items->contains(fn ($product) => (is_object($product) ? ($product->Product_Name ?? '') : $product) === $selectedItem))
                                        <li><button type="button" class="theme-dropdown-option is-selected" data-value="{{ $selectedItem }}" role="option" aria-selected="true">{{ $selectedItem }}</button></li>
                                    @endif
                                    <li class="theme-dropdown-empty">No matching items</li>
                                </ul>
                            </div>
                        </div>

                        <div class="field">
                            <label for="vehicleNo">Vehicle No.</label>
                            <input id="vehicleNo" type="text" name="vehicle_no" maxlength="13" value="{{ old('vehicle_no') }}" placeholder="GJ01AB1234" title="Use Indian format: GJ01AB1234 or 22BH1234AA">
                        </div>

                        <div class="field">
                            <label for="transporter">Transporter</label>
                            <input id="transporter" type="text" name="transporter" maxlength="255" value="{{ old('transporter') }}">
                            <span class="char-limit" data-char-limit-for="transporter">0/255</span>
                        </div>

                        <div class="field">
                            <label for="driver">Driver</label>
                            <input id="driver" type="text" name="driver" maxlength="255" value="{{ old('driver') }}">
                            <span class="char-limit" data-char-limit-for="driver">0/255</span>
                        </div>

                        <div class="field">
                            <label for="quantity">Quantity</label>
                            <input id="quantity" class="number-input" type="number" name="quantity" min="0" max="999999.999" step="0.001" data-decimal-places="3" data-max-value="999999.999" value="{{ old('quantity', '0.000') }}">
                        </div>

                        <div class="field">
                            <label for="rate">Rate</label>
                            <input id="rate" class="number-input" type="number" name="rate" min="0" max="99999999.99" step="0.01" data-decimal-places="2" data-max-value="99999999.99" value="{{ old('rate', ($latestRates[$selectedItem] ?? '0.00')) }}">
                        </div>

                        <div class="field">
                            <label for="amount">Amount</label>
                            <input id="amount" class="number-input" type="number" name="amount" min="0" step="0.01" value="{{ old('amount', '0.00') }}" readonly>
                        </div>

                        <div class="field">
                            <label for="discountPercent">Discount %</label>
                            <input id="discountPercent" class="number-input" type="number" name="discount%" min="0" max="100" step="0.01" data-decimal-places="2" data-max-value="100" value="{{ old('discount%', '0.00') }}">
                        </div>

                        <div class="field">
                            <label for="discountInRs">Discount In Rs</label>
                            <input id="discountInRs" class="number-input" type="number" name="discountinrs" min="0" step="0.01" value="{{ old('discountinrs', '0.00') }}" readonly>
                        </div>

                        <div class="field">
                            <label for="taxableAmount">Taxable Amount</label>
                            <input id="taxableAmount" class="number-input" type="number" name="taxable_amount" min="0" step="0.01" value="{{ old('taxable_amount', '0.00') }}" readonly>
                        </div>

                        <div class="field">
                            <label for="cgst">CGST %</label>
                            <input id="cgst" class="number-input" type="text" inputmode="decimal" name="cgst" min="0" max="100" step="0.01" data-decimal-places="2" data-max-value="100" value="{{ old('cgst', '0.00') }}">
                        </div>

                        <div class="field">
                            <label for="sgst">SGST %</label>
                            <input id="sgst" class="number-input" type="text" inputmode="decimal" name="sgst" min="0" max="100" step="0.01" data-decimal-places="2" data-max-value="100" value="{{ old('sgst', '0.00') }}">
                        </div>

                        <div class="field">
                            <label for="igst">IGST %</label>
                            <input id="igst" class="number-input" type="text" inputmode="decimal" name="igst" min="0" max="100" step="0.01" data-decimal-places="2" data-max-value="100" value="{{ old('igst', '0.00') }}">
                        </div>

                        <div class="field">
                            <label for="totalTaxAmount">Total Tax Amount</label>
                            <input id="totalTaxAmount" class="number-input" type="number" name="total_tax_amount" min="0" step="0.01" value="{{ old('total_tax_amount', '0.00') }}" readonly>
                        </div>

                        <div class="field">
                            <label for="totalAmount">Total Amount</label>
                            <input id="totalAmount" class="number-input" type="number" name="total_amount" min="0" step="0.01" value="{{ old('total_amount', '0.00') }}" readonly>
                        </div>

                        <div class="form-actions">
                            <div class="secondary-actions">
                                <button class="action-btn clear-btn" type="reset">Clear</button>
                                <button class="action-btn sample-btn" type="button" id="sampleButton">Sample</button>
                                <button class="action-btn cancel-edit-btn" type="button" id="cancelEditButton" hidden>Cancel Update</button>
                            </div>
                            <div class="primary-actions">
                                <button class="action-btn save-btn" type="submit" id="saveButton">Enter</button>
                            </div>
                        </div>
                    </div>

                    <datalist id="purchaseItems">
                        @foreach ($items as $product)
                            <option value="{{ is_object($product) ? ($product->Product_Name ?? '') : $product }}"></option>
                        @endforeach
                    </datalist>

                </form>
            </section>

            <section class="panel list-panel" id="purchaseList" aria-labelledby="purchaseListTitle">
                <div class="table-toolbar">
                    <div class="toolbar-title" id="purchaseListTitle">Purchase List</div>
                    <div class="toolbar-actions">
                        <button class="export-btn batch-save-btn" type="button" id="batchSaveButton" disabled>Save</button>
                        <input type="search" class="list-search" id="purchaseListSearch" placeholder="Search purchase" data-table-search="purchaseItemsBody">
                        @if ($purchases->isNotEmpty() && ($hasPdfRoute || $hasExcelRoute))
                            <div class="export-actions" aria-label="Purchase export actions">
                                @if ($hasPdfRoute)
                                    <a href="{{ route('purchase.pdf', ['date' => $today]) }}" class="export-btn" target="_blank" rel="noopener" data-themed-export>PDF</a>
                                @endif
                                @if ($hasExcelRoute)
                                    <a href="{{ route('purchase.excel', ['date' => $today]) }}" class="export-btn" data-themed-export>Excel</a>
                                @endif
                            </div>
                        @endif
                        <div class="toolbar-total">Total: {{ number_format($totalPurchaseAmount, 2) }}</div>
                    </div>
                </div>

                <div class="table-wrap">
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Ref No</th>
                                <th>Invoice No</th>
                                <th>Particulars</th>
                                <th>Postal Address</th>
                                <th>Location</th>
                                <th>Interstate</th>
                                <th>Item</th>
                                <th>Vehicle No</th>
                                <th>Transporter</th>
                                <th>Driver</th>
                                <th class="number-cell">Qty.</th>
                                <th class="number-cell">Rate</th>
                                <th class="number-cell">Amount</th>
                                <th class="number-cell">Discount %</th>
                                <th class="number-cell">Discount</th>
                                <th class="number-cell">Taxable Amt.</th>
                                <th class="number-cell">CGST %</th>
                                <th class="number-cell">SGST %</th>
                                <th class="number-cell">IGST %</th>
                                <th class="number-cell">Total Tax</th>
                                <th class="number-cell">Total Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="purchaseItemsBody">
                            @forelse ($purchases as $purchase)
                                @php
                                    $accountDetails = $accountDetailsByName->get($purchase->perticulars, ['address' => '', 'location' => '']);
                                    $purchasePostalAddress = $purchase->{'postal address'} ?: ($accountDetails['address'] ?? '');
                                    $purchaseLocation = $purchase->location ?: ($accountDetails['location'] ?? '');
                                @endphp
                                <tr>
                                    <td>{{ substr((string) $purchase->date, 0, 10) }}</td>
                                    <td>{{ $purchase->Ref_no }}</td>
                                    <td>{{ $purchase->invoice_no }}</td>
                                    <td>{{ $purchase->perticulars }}</td>
                                    <td>{{ $purchasePostalAddress ?: '-' }}</td>
                                    <td>{{ $purchaseLocation ?: '-' }}</td>
                                    <td>{{ $purchase->interstate }}</td>
                                    <td>{{ $purchase->item_name }}</td>
                                    <td>{{ $purchase->vehicle_no }}</td>
                                    <td>{{ $purchase->transporter }}</td>
                                    <td>{{ $purchase->driver }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->quantity, 3) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->rate, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->amount, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->{'discount%'}, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->discountinrs, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->taxable_amount, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->cgst, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->sgst, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->igst, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->total_tax_amount, 2) }}</td>
                                    <td class="number-cell">{{ number_format((float) $purchase->total_amount, 2) }}</td>
                                    <td>
                                        <div class="row-actions">
                                            @if ($hasUpdateRoute)
                                                <button
                                                    type="button"
                                                    class="update-btn"
                                                    data-edit-purchase
                                                    data-update-url="{{ route('purchase.update', $purchase) }}"
                                                    data-ref-no="{{ $purchase->Ref_no }}"
                                                    data-perticulars="{{ $purchase->perticulars }}"
                                                    data-interstate="{{ $purchase->interstate }}"
                                                    data-postal-address="{{ $purchasePostalAddress }}"
                                                    data-location="{{ $purchaseLocation }}"
                                                    data-date="{{ substr((string) $purchase->date, 0, 10) }}"
                                                    data-invoice-no="{{ $purchase->invoice_no }}"
                                                    data-vehicle-no="{{ $purchase->vehicle_no }}"
                                                    data-transporter="{{ $purchase->transporter }}"
                                                    data-driver="{{ $purchase->driver }}"
                                                    data-item-name="{{ $purchase->item_name }}"
                                                    data-quantity="{{ $purchase->quantity }}"
                                                    data-rate="{{ $purchase->rate }}"
                                                    data-discount-percent="{{ $purchase->{'discount%'} }}"
                                                    data-cgst="{{ $purchase->cgst }}"
                                                    data-sgst="{{ $purchase->sgst }}"
                                                    data-igst="{{ $purchase->igst }}"
                                                >
                                                    Update
                                                </button>
                                            @endif

                                            @if ($hasDestroyRoute)
                                                <form method="POST" action="{{ route('purchase.destroy', $purchase) }}" class="delete-form">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="delete-btn" data-delete-purchase="Ref {{ $purchase->Ref_no }}">Delete</button>
                                                </form>
                                            @endif

                                            @unless ($hasUpdateRoute || $hasDestroyRoute)
                                                <span class="toolbar-total">No actions</span>
                                            @endunless
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr data-saved-empty>
                                    <td colspan="23" class="empty-state">No purchase entries found.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if ($purchases->isNotEmpty())
                    <div class="purchase-summary-grid" aria-label="Today purchase summary">
                        <div class="summary-box">
                            <span class="summary-label">Total Entry</span>
                            <span class="summary-value">{{ $purchases->count() }}</span>
                        </div>
                        <div class="summary-box">
                            <span class="summary-label">Taxable Amount</span>
                            <span class="summary-value">{{ number_format($totalTaxableAmount, 2) }}</span>
                        </div>
                        <div class="summary-box">
                            <span class="summary-label">CGST Amount</span>
                            <span class="summary-value">{{ number_format($totalCgstAmount, 2) }}</span>
                        </div>
                        <div class="summary-box">
                            <span class="summary-label">SGST Amount</span>
                            <span class="summary-value">{{ number_format($totalSgstAmount, 2) }}</span>
                        </div>
                        <div class="summary-box">
                            <span class="summary-label">IGST Amount</span>
                            <span class="summary-value">{{ number_format($totalIgstAmount, 2) }}</span>
                        </div>
                        <div class="summary-box">
                            <span class="summary-label">Total Discount</span>
                            <span class="summary-value">{{ number_format($totalDiscountAmount, 2) }}</span>
                        </div>
                        <div class="summary-box total">
                            <span class="summary-label">Total Amount</span>
                            <span class="summary-value">{{ number_format($totalPurchaseAmount, 2) }}</span>
                        </div>
                    </div>
                @endif
            </section>

            @if (false && $purchaseSamples->isNotEmpty())
                <section class="panel list-panel" aria-labelledby="purchaseSampleListTitle">
                    <div class="table-toolbar">
                        <div class="toolbar-title" id="purchaseSampleListTitle">Purchase Sample List</div>
                        <div class="toolbar-actions">
                            <input type="search" class="list-search" id="purchaseSampleListSearch" placeholder="Search sample" data-table-search="purchaseSampleItemsBody">
                            @if ($purchaseSamples->isNotEmpty() && ($hasSamplePdfRoute || $hasSampleExcelRoute))
                                <div class="export-actions" aria-label="Purchase sample export actions">
                                    @if ($hasSamplePdfRoute)
                                        <a href="{{ route('purchase.sample.pdf', ['date' => $today]) }}" class="export-btn" target="_blank" rel="noopener" data-themed-export>PDF</a>
                                    @endif
                                    @if ($hasSampleExcelRoute)
                                        <a href="{{ route('purchase.sample.excel', ['date' => $today]) }}" class="export-btn" data-themed-export>Excel</a>
                                    @endif
                                </div>
                            @endif
                            <div class="toolbar-total">{{ $purchaseSamples->count() }} {{ $purchaseSamples->count() === 1 ? 'entry' : 'entries' }}</div>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Tanker</th>
                                    <th>Transport</th>
                                    <th>Oil Company</th>
                                    <th>Invoice No.</th>
                                    <th>Product</th>
                                    <th class="number-cell">HSD Temp</th>
                                    <th class="number-cell">HSD Density</th>
                                    <th>HSD Sample</th>
                                    <th>MS Sample</th>
                                    <th>Power MS Sample</th>
                                </tr>
                            </thead>
                            <tbody id="purchaseSampleItemsBody">
                                @foreach ($purchaseSamples as $sample)
                                    <tr>
                                        <td>{{ optional($sample->date)->format('Y-m-d') ?: '-' }}</td>
                                        <td>{{ $sample->tanker ?: '-' }}</td>
                                        <td>{{ $sample->transport ?: '-' }}</td>
                                        <td>{{ $sample->oil_company ?: '-' }}</td>
                                        <td>{{ $sample->invoice_no ?: '-' }}</td>
                                        <td>{{ $sample->product ?: '-' }}</td>
                                        <td class="number-cell">{{ number_format((float) $sample->hsd_temp, 2) }}</td>
                                        <td class="number-cell">{{ number_format((float) $sample->hsd_base_density, 4) }}</td>
                                        <td>{{ $sample->hsd_sample ?: '-' }}</td>
                                        <td>{{ $sample->ms_sample ?: '-' }}</td>
                                        <td>{{ $sample->power_ms_sample ?: '-' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>
            @endif
            </div>
        </main>
    </div>

    <div class="sample-modal" id="samplePurchaseModal" role="dialog" aria-modal="true" aria-labelledby="sampleModalTitle" aria-hidden="true">
        <div class="sample-window">
            <div class="sample-window-head">
                <div class="sample-window-title" id="sampleModalTitle">Purchase Sample</div>
                <button type="button" class="sample-close-btn" id="sampleCloseButton" aria-label="Close sample form">&times;</button>
            </div>

            <form class="sample-form" id="samplePurchaseForm" method="POST" action="{{ $hasSampleStoreRoute ? route('purchase.sample.store') : '#' }}" autocomplete="off">
                @csrf
                <div class="sample-details">
                    <div class="sample-field">
                        <label for="sampleDate">Date</label>
                        <input id="sampleDate" name="date" type="date" value="{{ $today }}" readonly>
                    </div>
                    <div class="sample-field">
                        <label for="sampleTanker">Tanker</label>
                        <input id="sampleTanker" name="tanker" type="text" value="" readonly>
                    </div>
                    <div class="sample-field">
                        <label for="sampleTransport">Transport</label>
                        <input id="sampleTransport" name="transport" type="text" value="" readonly>
                    </div>
                    <div class="sample-field">
                        <label for="sampleOilCompany">Oil Company</label>
                        <input id="sampleOilCompany" name="oil_company" type="text" value="" readonly>
                    </div>
                    <div class="sample-field">
                        <label for="sampleInvoiceNo">Invoice No.</label>
                        <input id="sampleInvoiceNo" name="invoice_no" type="text" value="" readonly>
                    </div>
                    <div class="sample-field">
                        <label for="sampleProduct">Product</label>
                        <input id="sampleProduct" name="product" type="text" value="">
                    </div>
                </div>

                <div class="sample-products">
                    @foreach (['HSD', 'MS', 'POWER MS'] as $productLabel)
                        @php $productKey = \Illuminate\Support\Str::of($productLabel)->lower()->replace(' ', '-'); @endphp
                        <div class="sample-product-card" data-sample-product="{{ $productKey }}">
                            <h3>{{ $productLabel }}</h3>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-temp">Temp</label>
                                <input id="sample-{{ $productKey }}-temp" name="{{ str_replace('-', '_', $productKey) }}_temp" type="number" step="0.01" value="0.00">
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-density">Base Density</label>
                                <input id="sample-{{ $productKey }}-density" name="{{ str_replace('-', '_', $productKey) }}_base_density" type="number" step="0.0001" value="0.0000">
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-value">Value</label>
                                <input id="sample-{{ $productKey }}-value" name="{{ str_replace('-', '_', $productKey) }}_value" type="number" step="0.0001" value="0.0000" readonly>
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-sample">Sample</label>
                                <input id="sample-{{ $productKey }}-sample" name="{{ str_replace('-', '_', $productKey) }}_sample" type="text" value="{{ $productLabel === 'HSD' ? '' : 'F' }}">
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-invoice-sample">Invoice Sample</label>
                                <input id="sample-{{ $productKey }}-invoice-sample" name="{{ str_replace('-', '_', $productKey) }}_invoice_sample" type="text" value="{{ $productLabel === 'HSD' ? '' : 'F' }}">
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-plastic-seal">Plastic Seal</label>
                                <input id="sample-{{ $productKey }}-plastic-seal" name="{{ str_replace('-', '_', $productKey) }}_plastic_seal" type="text" value="{{ $productLabel === 'HSD' ? '' : 'F' }}">
                            </div>
                            <div class="sample-line">
                                <label for="sample-{{ $productKey }}-aluminium-seal">Aluminium Seal</label>
                                <input id="sample-{{ $productKey }}-aluminium-seal" name="{{ str_replace('-', '_', $productKey) }}_aluminium_seal" type="text" value="{{ $productLabel === 'HSD' ? '' : 'F' }}">
                            </div>
                            <button type="button" class="sample-preview-btn" data-sample-preview="{{ $productKey }}">{{ $productLabel }} Preview</button>
                        </div>
                    @endforeach
                </div>
            </form>
        </div>
    </div>

    <div class="delete-modal" id="deleteConfirmModal" role="dialog" aria-modal="true" aria-labelledby="deleteModalTitle" aria-hidden="true">
        <div class="delete-dialog">
            <h2 class="delete-dialog-title" id="deleteModalTitle">Do you want to delete?</h2>
            <p class="delete-dialog-body">Are you sure you want to delete <strong id="deletePurchaseName">this entry</strong>? This action cannot be undone.</p>
            <div class="delete-dialog-actions">
                <button type="button" class="modal-no-btn" id="deleteCancelBtn">No</button>
                <button type="button" class="modal-yes-btn" id="deleteConfirmBtn">Yes</button>
            </div>
        </div>
    </div>

    <div class="delete-modal density-alert-modal" id="densityInvalidModal" role="dialog" aria-modal="true" aria-labelledby="densityInvalidTitle" aria-hidden="true">
        <div class="delete-dialog">
            <h2 class="delete-dialog-title density-alert-title" id="densityInvalidTitle">Invalid Density Details</h2>
            <p class="delete-dialog-body" id="densityInvalidMessage">Temp or Base Density invalid.</p>
            <div class="delete-dialog-actions">
                <button type="button" class="modal-no-btn density-alert-ok" id="densityInvalidOkBtn">OK</button>
            </div>
        </div>
    </div>

    <div class="delete-modal density-alert-modal" id="samplePreviewModal" role="dialog" aria-modal="true" aria-labelledby="samplePreviewTitle" aria-hidden="true">
        <div class="delete-dialog">
            <h2 class="delete-dialog-title" id="samplePreviewTitle">Sample Preview</h2>
            <div class="sample-preview-grid" id="samplePreviewGrid"></div>
            <div class="delete-dialog-actions">
                <button type="button" class="modal-no-btn density-alert-ok" id="samplePreviewOkBtn">OK</button>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('[data-theme-dropdown]').forEach((dropdown) => {
            const valueInput = dropdown.querySelector('.theme-dropdown-value');
            const button = dropdown.querySelector('.theme-dropdown-button');
            const text = dropdown.querySelector('.theme-dropdown-text');
            const search = dropdown.querySelector('.theme-dropdown-search');
            const options = Array.from(dropdown.querySelectorAll('.theme-dropdown-option:not(:disabled)'));
            const empty = dropdown.querySelector('.theme-dropdown-empty');
            const placeholder = text.textContent.trim();

            const closeDropdown = () => {
                dropdown.classList.remove('is-open');
                button.setAttribute('aria-expanded', 'false');
                dropdown.closest('.form-panel')?.classList.remove('has-open-dropdown');
            };

            const openDropdown = () => {
                document.querySelectorAll('[data-theme-dropdown].is-open').forEach((openItem) => {
                    if (openItem !== dropdown) {
                        openItem.classList.remove('is-open');
                        openItem.querySelector('.theme-dropdown-button')?.setAttribute('aria-expanded', 'false');
                        openItem.closest('.form-panel')?.classList.remove('has-open-dropdown');
                    }
                });

                dropdown.classList.add('is-open');
                button.setAttribute('aria-expanded', 'true');
                dropdown.closest('.form-panel')?.classList.add('has-open-dropdown');
                search?.focus();
            };

            const setValue = (value, label = value) => {
                valueInput.value = value;
                valueInput.dispatchEvent(new Event('change', { bubbles: true }));
                text.textContent = label || placeholder;
                options.forEach((option) => {
                    const isSelected = option.dataset.value === value;
                    option.classList.toggle('is-selected', isSelected);
                    option.setAttribute('aria-selected', String(isSelected));
                });
            };

            const filterOptions = () => {
                const query = (search?.value || '').trim().toLowerCase();
                let visibleCount = 0;

                options.forEach((option) => {
                    const isVisible = option.textContent.trim().toLowerCase().includes(query);
                    option.closest('li').style.display = isVisible ? '' : 'none';
                    visibleCount += isVisible ? 1 : 0;
                });

                empty?.classList.toggle('is-visible', visibleCount === 0);
            };

            button.addEventListener('click', () => {
                if (dropdown.classList.contains('is-open')) {
                    closeDropdown();
                    return;
                }

                openDropdown();
            });

            options.forEach((option) => {
                option.addEventListener('click', () => {
                    setValue(option.dataset.value || option.textContent.trim(), option.textContent.trim());
                    if (valueInput?.id === 'perticulars') {
                        syncSupplierDetails(option);
                    }
                    if (valueInput?.id === 'itemName') {
                        applyLatestRate(option.dataset.value || option.textContent.trim());
                    }
                    closeDropdown();
                    button.focus();
                });
            });

            search?.addEventListener('input', filterOptions);

            dropdown.addEventListener('keydown', (event) => {
                if (event.key === 'Escape') {
                    closeDropdown();
                    button.focus();
                }
            });
        });

        document.addEventListener('click', (event) => {
            document.querySelectorAll('[data-theme-dropdown].is-open').forEach((dropdown) => {
                if (!dropdown.contains(event.target)) {
                    dropdown.classList.remove('is-open');
                    dropdown.querySelector('.theme-dropdown-button')?.setAttribute('aria-expanded', 'false');
                    dropdown.closest('.form-panel')?.classList.remove('has-open-dropdown');
                }
            });
        });

        const interstateInput = document.getElementById('interstate');
        const postalAddressInput = document.getElementById('postalAddress');
        const locationInput = document.getElementById('location');
        const vehicleNoInput = document.getElementById('vehicleNo');
        const quantityInput = document.getElementById('quantity');
        const rateInput = document.getElementById('rate');
        const amountInput = document.getElementById('amount');
        const discountPercentInput = document.getElementById('discountPercent');
        const discountInRsInput = document.getElementById('discountInRs');
        const taxableAmountInput = document.getElementById('taxableAmount');
        const totalAmountInput = document.getElementById('totalAmount');
        const cgstInput = document.getElementById('cgst');
        const sgstInput = document.getElementById('sgst');
        const igstInput = document.getElementById('igst');
        const totalTaxAmountInput = document.getElementById('totalTaxAmount');
        const limitedNumberInputs = document.querySelectorAll('[data-decimal-places]');
        const charLimitLabels = document.querySelectorAll('[data-char-limit-for]');
        const purchaseForm = document.getElementById('purchaseForm');
        const formMethodInput = document.getElementById('purchaseFormMethod');
        const saveButton = document.getElementById('saveButton');
        const batchSaveButton = document.getElementById('batchSaveButton');
        const pendingPurchaseItemsBody = document.getElementById('purchaseItemsBody');
        const pendingPurchaseList = document.getElementById('purchaseList');
        const pendingPurchaseTotal = pendingPurchaseList?.querySelector('.toolbar-total');
        const itemNameInput = document.getElementById('itemName');
        const perticularsInput = document.getElementById('perticulars');
        const sampleButton = document.getElementById('sampleButton');
        const sampleModal = document.getElementById('samplePurchaseModal');
        const sampleCloseButton = document.getElementById('sampleCloseButton');
        const cancelEditButton = document.getElementById('cancelEditButton');
        const purchaseList = document.getElementById('purchaseList');
        const purchaseListUrl = @json($listUrl);
        const nextRefNo = @json((string) ($nextRefNo ?? 1));
        const samplePrefillPurchase = @json($samplePrefillPurchase);
        const sampleActiveProducts = @json($sampleActiveProducts);
        const densityLookup = @json($densityLookup ?? ['hsd' => [], 'ms' => [], 'power-ms' => []]);
        const latestRates = @json($latestRates ?? []);
        const samplePreviewUrl = @json($samplePreviewUrl);
        const editButtons = document.querySelectorAll('[data-edit-purchase]');
        const tableSearchInputs = document.querySelectorAll('[data-table-search]');
        const deleteForms = document.querySelectorAll('.delete-form');
        const deleteModal = document.getElementById('deleteConfirmModal');
        const deletePurchaseName = document.getElementById('deletePurchaseName');
        const deleteCancelBtn = document.getElementById('deleteCancelBtn');
        const deleteConfirmBtn = document.getElementById('deleteConfirmBtn');
        const densityInvalidModal = document.getElementById('densityInvalidModal');
        const densityInvalidMessage = document.getElementById('densityInvalidMessage');
        const densityInvalidOkBtn = document.getElementById('densityInvalidOkBtn');
        const samplePreviewModal = document.getElementById('samplePreviewModal');
        const samplePreviewTitle = document.getElementById('samplePreviewTitle');
        const samplePreviewGrid = document.getElementById('samplePreviewGrid');
        const samplePreviewOkBtn = document.getElementById('samplePreviewOkBtn');
        let pendingDeleteForm = null;
        let pendingPurchaseItems = [];
        let isBatchSubmitting = false;
        const savedPurchaseRowsHtml = pendingPurchaseItemsBody?.innerHTML || '';
        const savedPurchaseTotalText = pendingPurchaseTotal?.textContent || 'Total: 0.00';

        window.setTimeout(() => {
            const successMessage = document.getElementById('success-message');

            if (!successMessage) {
                return;
            }

            successMessage.classList.add('is-hiding');
            window.setTimeout(() => successMessage.remove(), 200);
        }, 2000);

        const applyExportThemeLinks = () => {
            let theme = 'default';

            try {
                theme = localStorage.getItem('fueltracker:theme') || 'default';
            } catch (error) {
                theme = 'default';
            }

            document.querySelectorAll('[data-themed-export]').forEach((link) => {
                const url = new URL(link.href, window.location.origin);
                url.searchParams.set('theme', theme);
                link.href = url.toString();
            });
        };

        tableSearchInputs.forEach((input) => {
            const tableBody = document.getElementById(input.dataset.tableSearch);

            if (!tableBody) {
                return;
            }

            const dataRows = Array.from(tableBody.querySelectorAll('tr')).filter((row) => !row.dataset.searchEmpty);
            const columnCount = tableBody.closest('table')?.querySelectorAll('thead th').length || 1;
            const emptyRow = document.createElement('tr');
            emptyRow.dataset.searchEmpty = 'true';
            emptyRow.hidden = true;
            emptyRow.innerHTML = `<td colspan="${columnCount}" class="empty-state">No matching entries found.</td>`;
            tableBody.appendChild(emptyRow);

            input.addEventListener('input', () => {
                const query = input.value.trim().toLowerCase();
                let visibleCount = 0;

                dataRows.forEach((row) => {
                    const isVisible = !query || row.textContent.toLowerCase().includes(query);
                    row.hidden = !isVisible;
                    visibleCount += isVisible ? 1 : 0;
                });

                emptyRow.hidden = visibleCount !== 0;
            });
        });

        const syncSupplierDetails = (option) => {
            if (!option) {
                return;
            }

            if (postalAddressInput) {
                postalAddressInput.value = (option.dataset.address || '').slice(0, postalAddressInput.maxLength || 255);
                postalAddressInput.dispatchEvent(new Event('input', { bubbles: true }));
            }

            if (locationInput) {
                locationInput.value = (option.dataset.location || '').slice(0, locationInput.maxLength || 255);
                locationInput.dispatchEvent(new Event('input', { bubbles: true }));
            }
        };

        charLimitLabels.forEach((label) => {
            const input = document.getElementById(label.dataset.charLimitFor);
            const maxLength = Number(input?.maxLength || 0);

            const updateLimit = () => {
                label.textContent = `${input?.value.length || 0}/${maxLength}`;
            };

            input?.addEventListener('input', updateLimit);
            updateLimit();
        });

        const setDropdownValue = (dropdown, value) => {
            if (!dropdown) {
                return;
            }

            const input = dropdown.querySelector('.theme-dropdown-value');
            const text = dropdown.querySelector('.theme-dropdown-text');
            const options = Array.from(dropdown.querySelectorAll('.theme-dropdown-option:not(:disabled)'));
            const fallback = input?.id === 'perticulars'
                ? 'Select Particulars'
                : (input?.id === 'itemName' ? 'Select Item' : 'No');

            if (input) {
                input.value = value || '';
                input.dispatchEvent(new Event('change', { bubbles: true }));
            }

            if (text) {
                text.textContent = value || fallback;
            }

            options.forEach((option) => {
                const selected = option.dataset.value === value;
                option.classList.toggle('is-selected', selected);
                option.setAttribute('aria-selected', String(selected));
            });
        };

        const applyLatestRate = (itemName) => {
            if (Object.prototype.hasOwnProperty.call(latestRates, itemName)) {
                rateInput.value = Number.parseFloat(latestRates[itemName] || '0').toFixed(2);
                calculatePurchaseTotals();
            }
        };

        purchaseForm?.addEventListener('focusin', (event) => {
            const focusedField = event.target.closest('.field, .form-actions');

            if (!focusedField || !purchaseForm) {
                return;
            }

            window.requestAnimationFrame(() => {
                const formRect = purchaseForm.getBoundingClientRect();
                const fieldRect = focusedField.getBoundingClientRect();
                const actionsHeight = purchaseForm.querySelector('.form-actions')?.offsetHeight || 0;
                const topGap = 12;
                const bottomGap = actionsHeight + 18;
                const visibleTop = formRect.top + topGap;
                const visibleBottom = formRect.bottom - bottomGap;

                if (fieldRect.bottom > visibleBottom) {
                    purchaseForm.scrollBy({
                        top: fieldRect.bottom - visibleBottom,
                        behavior: 'smooth',
                    });
                } else if (fieldRect.top < visibleTop) {
                    purchaseForm.scrollBy({
                        top: fieldRect.top - visibleTop,
                        behavior: 'smooth',
                    });
                }
            });
        });

        limitedNumberInputs.forEach((input) => {
            input.addEventListener('keydown', (event) => {
                if (['e', 'E', '+', '-'].includes(event.key)) {
                    event.preventDefault();
                }
            });

            input.addEventListener('input', () => {
                const decimalPlaces = Number(input.dataset.decimalPlaces || 2);
                const maxValue = Number(input.dataset.maxValue || input.max || 0);
                const parts = input.value.replace(',', '.').replace(/[^0-9.]/g, '').split('.');
                const integerPart = parts[0] || '';
                const decimalPart = parts.slice(1).join('').slice(0, decimalPlaces);
                let cleanedValue = parts.length > 1 ? `${integerPart}.${decimalPart}` : integerPart;

                if (maxValue && Number(cleanedValue) > maxValue) {
                    cleanedValue = String(maxValue);
                }

                input.value = cleanedValue;
            });
        });

        const toggleTaxFields = () => {
            const value = interstateInput?.value;
            const isInterstate = value === 'Yes';
            const isLocal = value === 'No';

            if (cgstInput) {
                cgstInput.disabled = isInterstate;
                if (isInterstate) {
                    cgstInput.value = '';
                }
            }

            if (sgstInput) {
                sgstInput.disabled = isInterstate;
                if (isInterstate) {
                    sgstInput.value = '';
                }
            }

            if (igstInput) {
                igstInput.disabled = isLocal;
                if (isLocal) {
                    igstInput.value = '0.00';
                }
            }

            calculateTaxAmounts();
        };

        const setCreateMode = () => {
            if (!purchaseForm || !formMethodInput) {
                return;
            }

            purchaseForm.action = purchaseForm.dataset.storeUrl;
            formMethodInput.disabled = true;
            saveButton.textContent = 'Enter';
            cancelEditButton.hidden = true;
            document.getElementById('refNo').value = nextRefNo;
            enableCurrentPurchaseLine();
        };

        const setEditMode = (button) => {
            clearPendingPurchaseList();
            enableCurrentPurchaseLine();
            purchaseForm.action = button.dataset.updateUrl;
            formMethodInput.disabled = false;
            saveButton.textContent = 'Update';
            cancelEditButton.hidden = false;

            document.getElementById('refNo').value = button.dataset.refNo || '';
            setDropdownValue(document.querySelector('#perticulars')?.closest('[data-theme-dropdown]'), button.dataset.perticulars || '');
            setDropdownValue(document.querySelector('#interstate')?.closest('[data-theme-dropdown]'), button.dataset.interstate || 'No');
            document.getElementById('postalAddress').value = button.dataset.postalAddress || '';
            document.getElementById('location').value = button.dataset.location || '';
            document.getElementById('purchaseDate').value = button.dataset.date || '';
            document.getElementById('invoiceNo').value = button.dataset.invoiceNo || '';
            document.getElementById('vehicleNo').value = button.dataset.vehicleNo || '';
            document.getElementById('transporter').value = button.dataset.transporter || '';
            document.getElementById('driver').value = button.dataset.driver || '';
            setDropdownValue(document.querySelector('#itemName')?.closest('[data-theme-dropdown]'), button.dataset.itemName || '');
            quantityInput.value = button.dataset.quantity || '0.000';
            rateInput.value = button.dataset.rate || '0.00';
            discountPercentInput.value = button.dataset.discountPercent || '0.00';
            cgstInput.value = button.dataset.cgst || '0.00';
            sgstInput.value = button.dataset.sgst || '0.00';
            igstInput.value = button.dataset.igst || '0.00';

            calculatePurchaseTotals();
            toggleTaxFields();
            purchaseForm.closest('.form-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        };

        const fillSamplePurchaseDetails = () => {
            const valueFromForm = (id) => document.getElementById(id)?.value?.trim() || '';
            const setSampleValue = (id, value) => {
                const input = document.getElementById(id);

                if (input) {
                    input.value = value || '';
                }
            };

            setSampleValue('sampleDate', valueFromForm('purchaseDate') || samplePrefillPurchase.date || @json($today));
            setSampleValue('sampleTanker', valueFromForm('vehicleNo') || samplePrefillPurchase.tanker || '');
            setSampleValue('sampleTransport', valueFromForm('transporter') || samplePrefillPurchase.transport || '');
            setSampleValue('sampleOilCompany', valueFromForm('perticulars') || samplePrefillPurchase.oil_company || '');
            setSampleValue('sampleInvoiceNo', valueFromForm('invoiceNo') || samplePrefillPurchase.invoice_no || '');
        };

        const sampleProductKeyFromName = (productName) => {
            const name = String(productName || '').trim().toLowerCase();

            if (!name) {
                return '';
            }

            if (name.includes('power') || name.includes('po-ms') || name.includes('po ms')) {
                return 'power-ms';
            }

            if (name.includes('diesel') || name.includes('deisel') || name.includes('deisle') || name.includes('diesal') || name.includes('desal') || name.includes('hsd')) {
                return 'hsd';
            }

            if (name.includes('petrol') || /\bms\b/.test(name)) {
                return 'ms';
            }

            return '';
        };

        const densityLookupKey = (value) => {
            const numberValue = Number(String(value || '').replace(',', '.'));

            if (!Number.isFinite(numberValue)) {
                return '';
            }

            return numberValue.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
        };

        const densityPairLookupKey = (temperature, baseDensity) => {
            const temperatureKey = densityLookupKey(temperature);
            const baseDensityKey = densityLookupKey(baseDensity);

            return temperatureKey && baseDensityKey ? `${temperatureKey}|${baseDensityKey}` : '';
        };

        const updateSampleProductCards = () => {
            const activeProducts = new Set(sampleActiveProducts);

            document.querySelectorAll('[data-sample-product]').forEach((card) => {
                const productKey = card.dataset.sampleProduct || '';
                const isActive = activeProducts.has(productKey);

                card.classList.toggle('is-inactive', !isActive);
                card.querySelectorAll('input, button').forEach((control) => {
                    control.disabled = !isActive;
                });
            });
        };

        const fillDensityValues = (productKey) => {
            const densityInput = document.getElementById(`sample-${productKey}-density`);
            const tempInput = document.getElementById(`sample-${productKey}-temp`);
            const valueInput = document.getElementById(`sample-${productKey}-value`);

            if (!densityInput || !tempInput || !valueInput) {
                return;
            }

            const match = densityLookup?.[productKey]?.[densityPairLookupKey(tempInput.value, densityInput.value)];

            if (!match) {
                valueInput.value = '0.0000';
                return;
            }

            valueInput.value = Number(match.chart_val || 0).toFixed(4);
        };

        const openDensityInvalidModal = (message) => {
            if (densityInvalidMessage) {
                densityInvalidMessage.textContent = message;
            }

            densityInvalidModal?.classList.add('is-open');
            densityInvalidModal?.setAttribute('aria-hidden', 'false');
            densityInvalidOkBtn?.focus();
        };

        const closeDensityInvalidModal = () => {
            densityInvalidModal?.classList.remove('is-open');
            densityInvalidModal?.setAttribute('aria-hidden', 'true');
        };

        const closeSamplePreviewModal = () => {
            samplePreviewModal?.classList.remove('is-open');
            samplePreviewModal?.setAttribute('aria-hidden', 'true');
        };

        const escapePreviewText = (value) => String(value || '-')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

        const openSamplePreviewModal = (productKey) => {
            const productLabel = {
                hsd: 'HSD',
                ms: 'MS',
                'power-ms': 'POWER MS',
            }[productKey] || 'Sample';
            const fieldNamePrefix = productKey.replace('-', '_');
            const fields = [
                ['Date', document.getElementById('sampleDate')?.value],
                ['Tanker', document.getElementById('sampleTanker')?.value],
                ['Transport', document.getElementById('sampleTransport')?.value],
                ['Oil Company', document.getElementById('sampleOilCompany')?.value],
                ['Invoice No.', document.getElementById('sampleInvoiceNo')?.value],
                ['Temp', document.getElementById(`sample-${productKey}-temp`)?.value],
                ['Base Density', document.getElementById(`sample-${productKey}-density`)?.value],
                ['Value', document.getElementById(`sample-${productKey}-value`)?.value],
                ['Sample', document.querySelector(`[name="${fieldNamePrefix}_sample"]`)?.value],
                ['Invoice Sample', document.querySelector(`[name="${fieldNamePrefix}_invoice_sample"]`)?.value],
                ['Plastic Seal', document.querySelector(`[name="${fieldNamePrefix}_plastic_seal"]`)?.value],
                ['Aluminium Seal', document.querySelector(`[name="${fieldNamePrefix}_aluminium_seal"]`)?.value],
            ];

            if (samplePreviewTitle) {
                samplePreviewTitle.textContent = `${productLabel} Preview`;
            }

            if (samplePreviewGrid) {
                samplePreviewGrid.innerHTML = fields.map(([label, value]) => (
                    `<div class="sample-preview-item"><span>${escapePreviewText(label)}</span><strong>${escapePreviewText(value)}</strong></div>`
                )).join('');
            }

            samplePreviewModal?.classList.add('is-open');
            samplePreviewModal?.setAttribute('aria-hidden', 'false');
            samplePreviewOkBtn?.focus();
        };

        const openSamplePreviewPage = (productKey) => {
            const productLabel = {
                hsd: 'HSD',
                ms: 'MS',
                'power-ms': 'POWER MS',
            }[productKey] || 'Sample';
            const fieldNamePrefix = productKey.replace('-', '_');
            const url = new URL(samplePreviewUrl, window.location.origin);
            const params = {
                product_key: productKey,
                product_label: productLabel,
                date: document.getElementById('sampleDate')?.value || '',
                tanker: document.getElementById('sampleTanker')?.value || '',
                transport: document.getElementById('sampleTransport')?.value || '',
                oil_company: document.getElementById('sampleOilCompany')?.value || '',
                invoice_no: document.getElementById('sampleInvoiceNo')?.value || '',
                product: document.getElementById('sampleProduct')?.value || productLabel,
                temp: document.getElementById(`sample-${productKey}-temp`)?.value || '',
                base_density: document.getElementById(`sample-${productKey}-density`)?.value || '',
                value: document.getElementById(`sample-${productKey}-value`)?.value || '',
                sample: document.querySelector(`[name="${fieldNamePrefix}_sample"]`)?.value || '',
                invoice_sample: document.querySelector(`[name="${fieldNamePrefix}_invoice_sample"]`)?.value || '',
                plastic_seal: document.querySelector(`[name="${fieldNamePrefix}_plastic_seal"]`)?.value || '',
                aluminium_seal: document.querySelector(`[name="${fieldNamePrefix}_aluminium_seal"]`)?.value || '',
            };

            Object.entries(params).forEach(([key, value]) => {
                url.searchParams.set(key, value);
            });

            window.open(url.toString(), '_blank', 'noopener');
        };

        const showDensityInvalidPopup = (productKey) => {
            const densityInput = document.getElementById(`sample-${productKey}-density`);
            const tempInput = document.getElementById(`sample-${productKey}-temp`);

            if (!densityInput || !tempInput || densityInput.dataset.edited !== 'true' || tempInput.dataset.edited !== 'true') {
                return;
            }

            const lookupKey = densityPairLookupKey(tempInput.value, densityInput.value);

            if (!lookupKey || densityLookup?.[productKey]?.[lookupKey]) {
                return;
            }

            const productLabel = {
                hsd: 'HSD',
                ms: 'MS',
                'power-ms': 'POWER MS',
            }[productKey] || 'Product';

            openDensityInvalidModal(`${productLabel}: Temp or Base Density invalid.`);
        };

        const openSampleModal = () => {
            fillSamplePurchaseDetails();
            updateSampleProductCards();
            sampleModal?.classList.add('is-open');
            sampleModal?.setAttribute('aria-hidden', 'false');
            document.getElementById('sampleDate')?.focus();
        };

        const closeSampleModal = () => {
            sampleModal?.classList.remove('is-open');
            sampleModal?.setAttribute('aria-hidden', 'true');
        };

        const calculateAmount = () => {
            const quantity = parseFloat(quantityInput?.value || '0');
            const rate = parseFloat(rateInput?.value || '0');
            const amount = quantity * rate;

            if (amountInput) {
                amountInput.value = amount.toFixed(2);
            }
        };

        const calculateDiscountAmount = () => {
            const amount = parseFloat(amountInput?.value || '0');
            const discountPercent = parseFloat(discountPercentInput?.value || '0');
            const discountAmount = (amount * discountPercent) / 100;

            if (discountInRsInput) {
                discountInRsInput.value = discountAmount.toFixed(2);
            }
        };

        const calculateTaxableAmount = () => {
            const amount = parseFloat(amountInput?.value || '0');
            const discountAmount = parseFloat(discountInRsInput?.value || '0');
            const taxableAmount = amount - discountAmount;

            if (taxableAmountInput) {
                taxableAmountInput.value = taxableAmount.toFixed(2);
            }
        };

        const calculateTaxAmounts = () => {
            const taxableAmount = parseFloat(taxableAmountInput?.value || '0');
            const cgstPercent = interstateInput?.value === 'No' ? parseFloat(cgstInput?.value || '0') : 0;
            const sgstPercent = interstateInput?.value === 'No' ? parseFloat(sgstInput?.value || '0') : 0;
            const igstPercent = interstateInput?.value === 'Yes' ? parseFloat(igstInput?.value || '0') : 0;
            const cgstAmount = (taxableAmount * cgstPercent) / 100;
            const sgstAmount = (taxableAmount * sgstPercent) / 100;
            const igstAmount = (taxableAmount * igstPercent) / 100;
            const totalTaxAmount = cgstAmount + sgstAmount + igstAmount;
            const totalAmount = taxableAmount + totalTaxAmount;

            if (totalTaxAmountInput) {
                totalTaxAmountInput.value = totalTaxAmount.toFixed(2);
            }

            if (totalAmountInput) {
                totalAmountInput.value = totalAmount.toFixed(2);
            }
        };

        const calculatePurchaseTotals = () => {
            calculateAmount();
            calculateDiscountAmount();
            calculateTaxableAmount();
            calculateTaxAmounts();
        };

        const numberValue = (input) => Number.parseFloat(input?.value || '0') || 0;
        const textValue = (id) => document.getElementById(id)?.value?.trim() || '';
        const formatMoney = (value) => (Number.parseFloat(value || 0) || 0).toFixed(2);
        const formatQty = (value) => (Number.parseFloat(value || 0) || 0).toFixed(3);
        const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;',
        }[character]));

        const removeBatchHiddenInputs = () => {
            purchaseForm?.querySelectorAll('[data-batch-hidden]').forEach((input) => input.remove());
        };

        const appendBatchHiddenInput = (name, value) => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = value;
            input.dataset.batchHidden = 'true';
            purchaseForm.appendChild(input);
        };

        const buildBatchHiddenInputs = () => {
            removeBatchHiddenInputs();

            pendingPurchaseItems.forEach((item, index) => {
                appendBatchHiddenInput(`items[${index}][item_name]`, item.item_name);
                appendBatchHiddenInput(`items[${index}][quantity]`, item.quantity);
                appendBatchHiddenInput(`items[${index}][rate]`, item.rate);
                appendBatchHiddenInput(`items[${index}][discount%]`, item.discount_percent);
                appendBatchHiddenInput(`items[${index}][cgst]`, item.cgst);
                appendBatchHiddenInput(`items[${index}][sgst]`, item.sgst);
                appendBatchHiddenInput(`items[${index}][igst]`, item.igst);
            });
        };

        const validateRequiredInput = (input, message) => {
            if (!input) {
                return true;
            }

            input.setCustomValidity(input.value.trim() ? '' : message);
            return input.checkValidity();
        };

        const validatePurchaseHeader = () => {
            const isValid = validateRequiredInput(perticularsInput, 'Select particulars before saving.');

            if (!isValid) {
                purchaseForm.reportValidity();
            }

            return isValid;
        };

        const validateCurrentPurchaseLine = () => {
            const hasHeader = validateRequiredInput(perticularsInput, 'Select particulars before entering.');
            const hasItem = validateRequiredInput(itemNameInput, 'Select item before entering.');

            if (!hasHeader || !hasItem || !purchaseForm.reportValidity()) {
                return false;
            }

            return true;
        };

        const disableCurrentPurchaseLine = () => {
            [itemNameInput, quantityInput, rateInput, amountInput, discountPercentInput, discountInRsInput, taxableAmountInput, cgstInput, sgstInput, igstInput, totalTaxAmountInput, totalAmountInput]
                .forEach((input) => {
                    if (input) {
                        input.disabled = true;
                    }
                });
        };

        const enableCurrentPurchaseLine = () => {
            [itemNameInput, quantityInput, rateInput, amountInput, discountPercentInput, discountInRsInput, taxableAmountInput, cgstInput, sgstInput, igstInput, totalTaxAmountInput, totalAmountInput]
                .forEach((input) => {
                    if (input) {
                        input.disabled = false;
                    }
                });

            toggleTaxFields();
        };

        const updatePendingPurchaseList = () => {
            if (!pendingPurchaseItemsBody || !batchSaveButton) {
                return;
            }

            const hasItems = pendingPurchaseItems.length > 0;
            const total = pendingPurchaseItems.reduce((sum, item) => sum + (Number.parseFloat(item.total_amount) || 0), 0);
            batchSaveButton.disabled = !hasItems;

            if (pendingPurchaseTotal) {
                pendingPurchaseTotal.textContent = hasItems ? `Total: ${formatMoney(total)}` : savedPurchaseTotalText;
            }

            if (!hasItems) {
                pendingPurchaseItemsBody.innerHTML = savedPurchaseRowsHtml;
                removeBatchHiddenInputs();
                return;
            }

            pendingPurchaseItemsBody.innerHTML = pendingPurchaseItems.map((item, index) => `
                <tr>
                    <td>${escapeHtml(textValue('purchaseDate'))}</td>
                    <td>${escapeHtml(item.ref_no)}</td>
                    <td>${escapeHtml(textValue('invoiceNo'))}</td>
                    <td>${escapeHtml(textValue('perticulars'))}</td>
                    <td>${escapeHtml(textValue('postalAddress') || '-')}</td>
                    <td>${escapeHtml(textValue('location') || '-')}</td>
                    <td>${escapeHtml(interstateInput?.value || 'No')}</td>
                    <td>${escapeHtml(item.item_name)}</td>
                    <td>${escapeHtml(textValue('vehicleNo'))}</td>
                    <td>${escapeHtml(textValue('transporter'))}</td>
                    <td>${escapeHtml(textValue('driver'))}</td>
                    <td class="number-cell">${formatQty(item.quantity)}</td>
                    <td class="number-cell">${formatMoney(item.rate)}</td>
                    <td class="number-cell">${formatMoney(item.amount)}</td>
                    <td class="number-cell">${formatMoney(item.discount_percent)}</td>
                    <td class="number-cell">${formatMoney((Number.parseFloat(item.amount) || 0) - (Number.parseFloat(item.taxable_amount) || 0))}</td>
                    <td class="number-cell">${formatMoney(item.taxable_amount)}</td>
                    <td class="number-cell">${formatMoney(item.cgst)}</td>
                    <td class="number-cell">${formatMoney(item.sgst)}</td>
                    <td class="number-cell">${formatMoney(item.igst)}</td>
                    <td class="number-cell">${formatMoney(item.total_tax_amount)}</td>
                    <td class="number-cell">${formatMoney(item.total_amount)}</td>
                    <td><button type="button" class="delete-btn" data-remove-pending-index="${index}">Remove</button></td>
                </tr>
            `).join('');
        };

        const resetCurrentPurchaseLine = () => {
            setDropdownValue(document.querySelector('#itemName')?.closest('[data-theme-dropdown]'), '');
            quantityInput.value = '0.000';
            rateInput.value = '0.00';
            discountPercentInput.value = '0.00';
            calculatePurchaseTotals();
        };

        const addCurrentPurchaseToList = () => {
            calculatePurchaseTotals();

            if (!validateCurrentPurchaseLine()) {
                return false;
            }

            pendingPurchaseItems.push({
                ref_no: textValue('refNo'),
                item_name: textValue('itemName'),
                quantity: numberValue(quantityInput).toFixed(3),
                rate: numberValue(rateInput).toFixed(2),
                amount: numberValue(amountInput).toFixed(2),
                discount_percent: numberValue(discountPercentInput).toFixed(2),
                taxable_amount: numberValue(taxableAmountInput).toFixed(2),
                cgst: interstateInput?.value === 'No' ? numberValue(cgstInput).toFixed(2) : '0.00',
                sgst: interstateInput?.value === 'No' ? numberValue(sgstInput).toFixed(2) : '0.00',
                igst: interstateInput?.value === 'Yes' ? numberValue(igstInput).toFixed(2) : '0.00',
                total_tax_amount: numberValue(totalTaxAmountInput).toFixed(2),
                total_amount: numberValue(totalAmountInput).toFixed(2),
            });

            updatePendingPurchaseList();
            resetCurrentPurchaseLine();
            document.querySelector('#itemName')?.closest('[data-theme-dropdown]')?.querySelector('.theme-dropdown-button')?.focus();
            return true;
        };

        const clearPendingPurchaseList = () => {
            pendingPurchaseItems = [];
            updatePendingPurchaseList();
        };

        quantityInput?.addEventListener('input', calculatePurchaseTotals);
        rateInput?.addEventListener('input', calculatePurchaseTotals);
        amountInput?.addEventListener('input', calculatePurchaseTotals);
        discountPercentInput?.addEventListener('input', calculatePurchaseTotals);
        discountInRsInput?.addEventListener('input', () => {
            calculateTaxableAmount();
            calculateTaxAmounts();
        });
        taxableAmountInput?.addEventListener('input', calculateTaxAmounts);
        cgstInput?.addEventListener('input', calculateTaxAmounts);
        sgstInput?.addEventListener('input', calculateTaxAmounts);
        igstInput?.addEventListener('input', calculateTaxAmounts);
        interstateInput?.addEventListener('change', toggleTaxFields);
        vehicleNoInput?.addEventListener('input', (event) => {
            event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9 -]/g, '').slice(0, 13);
        });
        document.getElementById('itemName')?.addEventListener('change', updateSampleProductCards);
        ['hsd', 'ms', 'power-ms'].forEach((productKey) => {
            const tempInput = document.getElementById(`sample-${productKey}-temp`);
            const densityInput = document.getElementById(`sample-${productKey}-density`);

            [tempInput, densityInput].forEach((input) => {
                input?.addEventListener('input', () => {
                    input.dataset.edited = 'true';
                    fillDensityValues(productKey);
                });
                input?.addEventListener('change', () => showDensityInvalidPopup(productKey));
            });
        });
        toggleTaxFields();
        applyExportThemeLinks();
        updatePendingPurchaseList();

        purchaseForm?.addEventListener('submit', (event) => {
            const isEditMode = formMethodInput && !formMethodInput.disabled;

            if (isEditMode || isBatchSubmitting) {
                return;
            }

            event.preventDefault();
            addCurrentPurchaseToList();
        });

        pendingPurchaseItemsBody?.addEventListener('click', (event) => {
            const removeButton = event.target.closest('[data-remove-pending-index]');

            if (!removeButton) {
                return;
            }

            pendingPurchaseItems.splice(Number(removeButton.dataset.removePendingIndex), 1);
            updatePendingPurchaseList();
        });

        batchSaveButton?.addEventListener('click', () => {
            if (!purchaseForm || pendingPurchaseItems.length === 0) {
                return;
            }

            if (!validatePurchaseHeader()) {
                return;
            }

            buildBatchHiddenInputs();
            disableCurrentPurchaseLine();
            isBatchSubmitting = true;

            if (!purchaseForm.checkValidity()) {
                isBatchSubmitting = false;
                enableCurrentPurchaseLine();
                purchaseForm.reportValidity();
                return;
            }

            purchaseForm.requestSubmit();
        });

        editButtons.forEach((button) => {
            button.addEventListener('click', () => setEditMode(button));
        });

        deleteForms.forEach((form) => {
            form.addEventListener('submit', (event) => {
                event.preventDefault();
                pendingDeleteForm = form;
                deletePurchaseName.textContent = form.querySelector('[data-delete-purchase]')?.dataset.deletePurchase || 'this entry';
                deleteModal.classList.add('is-open');
                deleteModal.setAttribute('aria-hidden', 'false');
            });
        });

        deleteCancelBtn?.addEventListener('click', () => {
            pendingDeleteForm = null;
            deleteModal.classList.remove('is-open');
            deleteModal.setAttribute('aria-hidden', 'true');
        });

        deleteConfirmBtn?.addEventListener('click', () => {
            if (pendingDeleteForm) {
                pendingDeleteForm.submit();
            }
        });

        deleteModal?.addEventListener('click', (event) => {
            if (event.target === deleteModal) {
                deleteCancelBtn.click();
            }
        });

        densityInvalidOkBtn?.addEventListener('click', closeDensityInvalidModal);
        densityInvalidModal?.addEventListener('click', (event) => {
            if (event.target === densityInvalidModal) {
                closeDensityInvalidModal();
            }
        });
        samplePreviewOkBtn?.addEventListener('click', closeSamplePreviewModal);
        samplePreviewModal?.addEventListener('click', (event) => {
            if (event.target === samplePreviewModal) {
                closeSamplePreviewModal();
            }
        });
        document.querySelectorAll('[data-sample-preview]').forEach((button) => {
            button.addEventListener('click', () => openSamplePreviewPage(button.dataset.samplePreview || ''));
        });

        document.getElementById('purchaseDate')?.addEventListener('change', (event) => {
            if (!formMethodInput || formMethodInput.disabled) {
                const url = new URL(purchaseListUrl, window.location.origin);
                url.searchParams.set('date', event.target.value);
                window.location.href = url.toString();
            }
        });

        cancelEditButton?.addEventListener('click', () => {
            purchaseForm.reset();
            setDropdownValue(document.querySelector('#perticulars')?.closest('[data-theme-dropdown]'), '');
            setDropdownValue(document.querySelector('#interstate')?.closest('[data-theme-dropdown]'), 'No');
            setDropdownValue(document.querySelector('#itemName')?.closest('[data-theme-dropdown]'), '');
            setCreateMode();
            calculatePurchaseTotals();
            toggleTaxFields();
            clearPendingPurchaseList();
        });

        sampleButton?.addEventListener('click', openSampleModal);
        sampleCloseButton?.addEventListener('click', closeSampleModal);
        sampleModal?.addEventListener('click', (event) => {
            if (event.target === sampleModal) {
                closeSampleModal();
            }
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && densityInvalidModal?.classList.contains('is-open')) {
                closeDensityInvalidModal();
                return;
            }

            if (event.key === 'Escape' && samplePreviewModal?.classList.contains('is-open')) {
                closeSamplePreviewModal();
                return;
            }

            if (event.key === 'Escape' && sampleModal?.classList.contains('is-open')) {
                closeSampleModal();
            }
        });

        purchaseForm?.addEventListener('reset', () => {
            window.setTimeout(() => {
                setDropdownValue(document.querySelector('#perticulars')?.closest('[data-theme-dropdown]'), '');
                setDropdownValue(document.querySelector('#interstate')?.closest('[data-theme-dropdown]'), 'No');
                setDropdownValue(document.querySelector('#itemName')?.closest('[data-theme-dropdown]'), '');
                setCreateMode();
                calculatePurchaseTotals();
                toggleTaxFields();
                clearPendingPurchaseList();
            }, 0);
        });

        @if (session('success'))
            window.addEventListener('load', () => {
                if (purchaseList) {
                    purchaseList.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        @endif
    </script>
</body>
</html>
